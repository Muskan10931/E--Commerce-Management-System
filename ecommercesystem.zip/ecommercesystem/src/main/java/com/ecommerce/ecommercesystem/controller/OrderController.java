package com.ecommerce.ecommercesystem.controller;

import com.ecommerce.ecommercesystem.model.Order;
import com.ecommerce.ecommercesystem.service.OrderService;
import com.ecommerce.ecommercesystem.service.OrderServiceImpl;
import java.util.List;
import java.util.Scanner;

/**
 * OrderController handles user interactions for order operations
 */
public class OrderController {
    
    private OrderService orderService;
    private Scanner scanner;
    
    public OrderController() {
        this.orderService = new OrderServiceImpl();
        this.scanner = new Scanner(System.in);
    }
    
    /**
     * Place order from cart
     */
    public void placeOrder(int customerId) {
        System.out.println("\n--- PLACE ORDER ---");
        
        System.out.print("Shipping Address: ");
        String address = scanner.nextLine();
        
        System.out.print("Payment Method (COD/Card/UPI): ");
        String paymentMethod = scanner.nextLine();
        
        if (orderService.placeOrder(customerId, address, paymentMethod)) {
            System.out.println("✅ Order placed successfully!");
        } else {
            System.out.println("❌ Failed to place order!");
        }
    }
    
    /**
     * View customer orders
     */
    public void viewCustomerOrders(int customerId) {
        List<Order> orders = orderService.getCustomerOrders(customerId);
        
        System.out.println("\n=== YOUR ORDERS ===");
        System.out.println("=".repeat(80));
        System.out.printf("%-10s %-15s %-20s %-15s %-10s\n", 
            "Order ID", "Date", "Amount", "Status", "Payment");
        System.out.println("=".repeat(80));
        
        if (orders.isEmpty()) {
            System.out.println("No orders found!");
        } else {
            for (Order order : orders) {
                System.out.printf("%-10d %-15s ₹%-20.2f %-15s %-10s\n", 
                    order.getOrderId(),
                    order.getOrderDate().toString().substring(0, 10),
                    order.getTotalAmount(),
                    order.getStatus(),
                    order.getPaymentMethod());
            }
        }
    }
    
    /**
     * View all orders (Admin only)
     */
    public void viewAllOrders() {
        List<Order> orders = orderService.getAllOrders();
        
        System.out.println("\n=== ALL ORDERS ===");
        System.out.println("=".repeat(100));
        System.out.printf("%-10s %-15s %-20s %-15s %-20s %-10s\n", 
            "Order ID", "Customer", "Date", "Amount", "Status", "Payment");
        System.out.println("=".repeat(100));
        
        if (orders.isEmpty()) {
            System.out.println("No orders found!");
        } else {
            for (Order order : orders) {
                System.out.printf("%-10d %-15s %-20s ₹%-15.2f %-20s %-10s\n", 
                    order.getOrderId(),
                    order.getCustomerName(),
                    order.getOrderDate().toString().substring(0, 10),
                    order.getTotalAmount(),
                    order.getStatus(),
                    order.getPaymentMethod());
            }
        }
    }
    
    /**
     * Update order status (Admin only)
     */
    public void updateOrderStatus() {
        System.out.print("\nEnter Order ID: ");
        int orderId = scanner.nextInt();
        scanner.nextLine();
        
        System.out.println("Select new status:");
        System.out.println("1. PENDING");
        System.out.println("2. PROCESSING");
        System.out.println("3. SHIPPED");
        System.out.println("4. DELIVERED");
        System.out.println("5. CANCELLED");
        System.out.print("Choice: ");
        
        int choice = scanner.nextInt();
        scanner.nextLine();
        
        String status = "";
        switch (choice) {
            case 1: status = "PENDING"; break;
            case 2: status = "PROCESSING"; break;
            case 3: status = "SHIPPED"; break;
            case 4: status = "DELIVERED"; break;
            case 5: status = "CANCELLED"; break;
            default: 
                System.out.println("Invalid choice!");
                return;
        }
        
        if (orderService.updateOrderStatus(orderId, status)) {
            System.out.println("✅ Order status updated!");
        } else {
            System.out.println("❌ Failed to update order status!");
        }
    }
}