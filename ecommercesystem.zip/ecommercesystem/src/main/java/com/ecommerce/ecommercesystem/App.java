package com.ecommerce.ecommercesystem;

import com.ecommerce.ecommercesystem.controller.*;
import com.ecommerce.ecommercesystem.util.DatabaseConnection;
import java.util.Scanner;

/**
 * Main application class - Entry point for E-commerce System
 */
public class App {
    
    private static Scanner scanner = new Scanner(System.in);
    private static int currentCustomerId = 0;
    private static String currentCustomerName = "";
    
    // Controllers
    private static CustomerController customerController;
    private static ProductController productController;
    private static OrderController orderController;
    private static AdminController adminController;
    
    public static void main(String[] args) {
        System.out.println("\n=================================");
        System.out.println("   E-COMMERCE MANAGEMENT SYSTEM");
        System.out.println("=================================\n");
        
        // Initialize database connection
        if (DatabaseConnection.getConnection() == null) {
            System.out.println("❌ Cannot connect to database. Exiting...");
            return;
        }
        
        // Initialize controllers
        initializeControllers();
        
        // Show main menu
        showMainMenu();
        
        // Close database connection when done
        DatabaseConnection.closeConnection();
    }
    
    /**
     * Initialize all controllers
     */
    private static void initializeControllers() {
        customerController = new CustomerController();
        productController = new ProductController();
        orderController = new OrderController();
        adminController = new AdminController();
    }
    
    /**
     * Display main menu
     */
    private static void showMainMenu() {
        while (true) {
            System.out.println("\n===== MAIN MENU =====");
            System.out.println("1. Customer Login");
            System.out.println("2. Customer Register");
            System.out.println("3. Browse Products");
            System.out.println("4. Admin Login");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            
            int choice = getChoice();
            
            switch (choice) {
                case 1:
                    handleCustomerLogin();
                    break;
                case 2:
                    handleCustomerRegistration();
                    break;
                case 3:
                    productController.showAllProducts();
                    break;
                case 4:
                    handleAdminLogin();
                    break;
                case 5:
                    System.out.println("\nThank you for using E-commerce System!");
                    return;
                default:
                    System.out.println("❌ Invalid choice! Please try again.");
            }
        }
    }
    
    /**
     * Handle customer login
     */
    private static void handleCustomerLogin() {
        com.ecommerce.ecommercesystem.model.Customer customer = customerController.login();
        if (customer != null) {
            currentCustomerId = customer.getCustomerId();
            currentCustomerName = customer.getName();
            showCustomerMenu();
        }
    }
    
    /**
     * Handle customer registration
     */
    private static void handleCustomerRegistration() {
        com.ecommerce.ecommercesystem.model.Customer customer = customerController.register();
        if (customer != null) {
            System.out.println("Please login with your new account.");
        }
    }
    
    /**
     * Show customer menu after login
     */
    private static void showCustomerMenu() {
        while (currentCustomerId > 0) {
            System.out.println("\n===== WELCOME " + currentCustomerName.toUpperCase() + " =====");
            System.out.println("1. Browse Products");
            System.out.println("2. Add to Cart");
            System.out.println("3. View Cart");
            System.out.println("4. Remove from Cart");
            System.out.println("5. Place Order");
            System.out.println("6. View My Orders");
            System.out.println("7. View Profile");
            System.out.println("8. Logout");
            System.out.print("Enter choice: ");
            
            int choice = getChoice();
            
            switch (choice) {
                case 1:
                    productController.showAllProducts();
                    break;
                case 2:
                    productController.addToCart(currentCustomerId);
                    break;
                case 3:
                    productController.viewCart(currentCustomerId);
                    break;
                case 4:
                    productController.removeFromCart();
                    break;
                case 5:
                    orderController.placeOrder(currentCustomerId);
                    break;
                case 6:
                    orderController.viewCustomerOrders(currentCustomerId);
                    break;
                case 7:
                    customerController.showCustomerMenu(currentCustomerId);
                    break;
                case 8:
                    currentCustomerId = 0;
                    currentCustomerName = "";
                    System.out.println("✅ Logged out successfully!");
                    break;
                default:
                    System.out.println("❌ Invalid choice!");
            }
        }
    }
    
    /**
     * Handle admin login
     */
    private static void handleAdminLogin() {
        if (adminController.login()) {
            showAdminMenu();
        }
    }
    
    /**
     * Show admin menu
     */
    private static void showAdminMenu() {
        while (true) {
            System.out.println("\n===== ADMIN PANEL =====");
            System.out.println("1. View All Products");
            System.out.println("2. Add New Product");
            System.out.println("3. View All Orders");
            System.out.println("4. Update Order Status");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter choice: ");
            
            int choice = getChoice();
            
            switch (choice) {
                case 1:
                    productController.showAllProducts();
                    break;
                case 2:
                    productController.addNewProduct();
                    break;
                case 3:
                    orderController.viewAllOrders();
                    break;
                case 4:
                    orderController.updateOrderStatus();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("❌ Invalid choice!");
            }
        }
    }
    
    /**
     * Get user choice with validation
     */
    private static int getChoice() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}