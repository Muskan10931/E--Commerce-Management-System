package com.ecommerce.ecommercesystem.controller;

import com.ecommerce.ecommercesystem.model.Product;
import com.ecommerce.ecommercesystem.service.ProductService;
import com.ecommerce.ecommercesystem.service.ProductServiceImpl;
import java.util.List;
import java.util.Scanner;

/**
 * ProductController handles user interactions for product operations
 */
public class ProductController {
    
    private ProductService productService;
    private Scanner scanner;
    
    public ProductController() {
        this.productService = new ProductServiceImpl();
        this.scanner = new Scanner(System.in);
    }
    
    /**
     * Display all products
     */
    public void showAllProducts() {
        List<Product> products = productService.getAllProducts();
        
        System.out.println("\n=== PRODUCT CATALOG ===");
        System.out.println("=".repeat(80));
        System.out.printf("%-5s %-30s %-20s %-10s %-10s\n", 
            "ID", "Name", "Category", "Price", "Stock");
        System.out.println("=".repeat(80));
        
        if (products.isEmpty()) {
            System.out.println("No products available!");
        } else {
            for (Product product : products) {
                System.out.printf("%-5d %-30s %-20s ₹%-10.2f %-10d\n", 
                    product.getProductId(),
                    product.getName().length() > 30 ? product.getName().substring(0, 27) + "..." : product.getName(),
                    product.getCategoryName() != null ? 
                        (product.getCategoryName().length() > 20 ? 
                         product.getCategoryName().substring(0, 17) + "..." : product.getCategoryName()) : "N/A",
                    product.getPrice(),
                    product.getStock());
            }
        }
    }
    
    /**
     * Add product to cart
     */
    public void addToCart(int customerId) {
        System.out.print("\nEnter Product ID to add to cart: ");
        int productId = scanner.nextInt();
        
        System.out.print("Enter Quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // Clear buffer
        
        if (productService.addToCart(customerId, productId, quantity)) {
            System.out.println("✅ Added to cart!");
        } else {
            System.out.println("❌ Failed to add to cart!");
        }
    }
    
    /**
     * View cart items
     */
    public void viewCart(int customerId) {
        List<Object[]> cartItems = productService.getCartItems(customerId);
        
        System.out.println("\n=== SHOPPING CART ===");
        System.out.println("=".repeat(80));
        System.out.printf("%-5s %-30s %-10s %-10s %-15s\n", 
            "ID", "Product", "Price", "Qty", "Total");
        System.out.println("=".repeat(80));
        
        if (cartItems.isEmpty()) {
            System.out.println("Your cart is empty!");
        } else {
            double cartTotal = 0;
            for (Object[] item : cartItems) {
                System.out.printf("%-5d %-30s ₹%-10.2f %-10d ₹%-15.2f\n", 
                    (int) item[0],
                    ((String) item[2]).length() > 30 ? 
                        ((String) item[2]).substring(0, 27) + "..." : (String) item[2],
                    (double) item[3],
                    (int) item[4],
                    (double) item[5]);
                cartTotal += (double) item[5];
            }
            System.out.println("=".repeat(80));
            System.out.printf("Cart Total: ₹%.2f\n", cartTotal);
        }
    }
    
    /**
     * Remove item from cart
     */
    public void removeFromCart() {
        System.out.print("\nEnter Cart Item ID to remove: ");
        int cartId = scanner.nextInt();
        scanner.nextLine();
        
        if (productService.removeFromCart(cartId)) {
            System.out.println("✅ Removed from cart!");
        } else {
            System.out.println("❌ Failed to remove from cart!");
        }
    }
    
    /**
     * Add new product (Admin only)
     */
    public void addNewProduct() {
        System.out.println("\n--- ADD NEW PRODUCT ---");
        
        System.out.print("Product Name: ");
        String name = scanner.nextLine();
        
        System.out.print("Description: ");
        String description = scanner.nextLine();
        
        System.out.print("Price: ");
        double price = scanner.nextDouble();
        
        System.out.print("Stock Quantity: ");
        int stock = scanner.nextInt();
        
        System.out.print("Category ID (1-Electronics, 2-Clothing, 3-Books): ");
        int categoryId = scanner.nextInt();
        scanner.nextLine();
        
        Product product = new Product(name, description, price, stock, categoryId);
        
        if (productService.addProduct(product)) {
            System.out.println("✅ Product added successfully!");
        } else {
            System.out.println("❌ Failed to add product!");
        }
    }
}