package com.ecommerce.ecommercesystem.service;

import com.ecommerce.ecommercesystem.dao.OrderDAO;
import com.ecommerce.ecommercesystem.dao.OrderDAOImpl;
import com.ecommerce.ecommercesystem.dao.ProductDAO;
import com.ecommerce.ecommercesystem.dao.ProductDAOImpl;
import com.ecommerce.ecommercesystem.model.Order;
import com.ecommerce.ecommercesystem.util.DatabaseConnection;
import java.sql.*;
import java.util.List;

/**
 * OrderServiceImpl implements OrderService interface
 */
public class OrderServiceImpl implements OrderService {
    
    private OrderDAO orderDAO;
    private ProductDAO productDAO;
    
    public OrderServiceImpl() {
        this.orderDAO = new OrderDAOImpl();
        this.productDAO = new ProductDAOImpl();
    }
    
    @Override
    public boolean placeOrder(int customerId, String shippingAddress, String paymentMethod) {
        // Calculate cart total
        double cartTotal = calculateCartTotal(customerId);
        
        if (cartTotal <= 0) {
            System.out.println("Cart is empty!");
            return false;
        }
        
        // Create order
        Order order = new Order(customerId, cartTotal, shippingAddress, paymentMethod);
        int orderId = orderDAO.createOrder(order);
        
        if (orderId == -1) {
            System.out.println("Failed to create order!");
            return false;
        }
        
        // Get cart items
        String cartSql = "SELECT product_id, quantity FROM cart WHERE customer_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement cartStmt = conn.prepareStatement(cartSql)) {
            
            cartStmt.setInt(1, customerId);
            ResultSet rs = cartStmt.executeQuery();
            
            // Process each cart item
            while (rs.next()) {
                int productId = rs.getInt("product_id");
                int quantity = rs.getInt("quantity");
                
                // Get product price
                String priceSql = "SELECT price FROM products WHERE product_id = ?";
                try (PreparedStatement priceStmt = conn.prepareStatement(priceSql)) {
                    priceStmt.setInt(1, productId);
                    ResultSet priceRs = priceStmt.executeQuery();
                    
                    if (priceRs.next()) {
                        double price = priceRs.getDouble("price");
                        
                        // Add to order items
                        orderDAO.addOrderItem(orderId, productId, quantity, price);
                        
                        // Update product stock
                        productDAO.updateProductStock(productId, quantity);
                    }
                }
            }
            
            // Clear cart
            String clearSql = "DELETE FROM cart WHERE customer_id = ?";
            try (PreparedStatement clearStmt = conn.prepareStatement(clearSql)) {
                clearStmt.setInt(1, customerId);
                clearStmt.executeUpdate();
            }
            
            // Create payment record
            String paymentSql = "INSERT INTO payments (order_id, amount, method, status) VALUES (?, ?, ?, 'COMPLETED')";
            try (PreparedStatement paymentStmt = conn.prepareStatement(paymentSql)) {
                paymentStmt.setInt(1, orderId);
                paymentStmt.setDouble(2, cartTotal);
                paymentStmt.setString(3, paymentMethod);
                paymentStmt.executeUpdate();
            }
            
            System.out.println("Order placed successfully! Order ID: " + orderId);
            return true;
            
        } catch (SQLException e) {
            System.out.println("Error placing order: " + e.getMessage());
        }
        
        return false;
    }
    
    @Override
    public List<Order> getCustomerOrders(int customerId) {
        return orderDAO.getOrdersByCustomer(customerId);
    }
    
    @Override
    public List<Order> getAllOrders() {
        return orderDAO.getAllOrders();
    }
    
    @Override
    public boolean updateOrderStatus(int orderId, String status) {
        return orderDAO.updateOrderStatus(orderId, status);
    }
    
    @Override
    public double calculateCartTotal(int customerId) {
        double total = 0;
        String sql = "SELECT SUM(p.price * c.quantity) as total FROM cart c " +
                    "JOIN products p ON c.product_id = p.product_id " +
                    "WHERE c.customer_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                total = rs.getDouble("total");
            }
        } catch (SQLException e) {
            System.out.println("Error calculating cart total: " + e.getMessage());
        }
        
        return total;
    }
}