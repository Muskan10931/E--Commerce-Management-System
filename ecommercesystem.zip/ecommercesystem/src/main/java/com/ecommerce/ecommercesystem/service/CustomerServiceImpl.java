package com.ecommerce.ecommercesystem.service;

import com.ecommerce.ecommercesystem.dao.CustomerDAO;
import com.ecommerce.ecommercesystem.dao.CustomerDAOImpl;
import com.ecommerce.ecommercesystem.model.Customer;

/**
 * CustomerServiceImpl implements CustomerService interface
 * Contains business logic and validations for Customer operations
 */
public class CustomerServiceImpl implements CustomerService {
    
    private CustomerDAO customerDAO;
    
    public CustomerServiceImpl() {
        this.customerDAO = new CustomerDAOImpl();
    }
    
    @Override
    public Customer registerCustomer(Customer customer) {
        // Validate input
        if (customer.getName() == null || customer.getName().trim().isEmpty()) {
            System.out.println("Name is required!");
            return null;
        }
        
        if (customer.getEmail() == null || customer.getEmail().trim().isEmpty()) {
            System.out.println("Email is required!");
            return null;
        }
        
        if (customer.getPassword() == null || customer.getPassword().trim().isEmpty()) {
            System.out.println("Password is required!");
            return null;
        }
        
        // Check if email already exists
        if (customerDAO.emailExists(customer.getEmail())) {
            System.out.println("Email already registered!");
            return null;
        }
        
        // Add customer to database
        if (customerDAO.addCustomer(customer)) {
            System.out.println("Registration successful!");
            return customer;
        } else {
            System.out.println("Registration failed!");
            return null;
        }
    }
    
    @Override
    public Customer loginCustomer(String email, String password) {
        if (email == null || email.trim().isEmpty()) {
            System.out.println("Email is required!");
            return null;
        }
        
        if (password == null || password.trim().isEmpty()) {
            System.out.println("Password is required!");
            return null;
        }
        
        Customer customer = customerDAO.getCustomerByEmailAndPassword(email, password);
        
        if (customer != null) {
            System.out.println("Login successful! Welcome " + customer.getName());
            return customer;
        } else {
            System.out.println("Invalid email or password!");
            return null;
        }
    }
    
    @Override
    public Customer getCustomerById(int customerId) {
        return customerDAO.getCustomerById(customerId);
    }
}