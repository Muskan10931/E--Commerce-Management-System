package com.ecommerce.ecommercesystem.dao;

import com.ecommerce.ecommercesystem.model.Product;
import java.util.List;

/**
 * ProductDAO interface defines database operations for Product entity
 */
public interface ProductDAO {
    // Get all products
    List<Product> getAllProducts();
    
    // Get product by ID
    Product getProductById(int productId);
    
    // Add new product
    boolean addProduct(Product product);
    
    // Update product stock
    boolean updateProductStock(int productId, int quantity);
    
    // Get products by category
    List<Product> getProductsByCategory(int categoryId);
}