package com.ecommerce.ecommercesystem.service;

import com.ecommerce.ecommercesystem.model.Order;
import java.util.List;

/**
 * OrderService interface defines business logic for Order operations
 */
public interface OrderService {
    // Place order
    boolean placeOrder(int customerId, String shippingAddress, String paymentMethod);
    
    // Get customer orders
    List<Order> getCustomerOrders(int customerId);
    
    // Get all orders
    List<Order> getAllOrders();
    
    // Update order status
    boolean updateOrderStatus(int orderId, String status);
    
    // Calculate cart total
    double calculateCartTotal(int customerId);
}