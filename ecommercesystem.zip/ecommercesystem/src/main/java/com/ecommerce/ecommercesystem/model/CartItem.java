package com.ecommerce.ecommercesystem.model;

/**
 * CartItem model class representing items in shopping cart
 */
public class CartItem {
    private int cartId;
    private int customerId;
    private int productId;
    private int quantity;
    private String addedDate;
    
    // For display
    private String productName;
    private double productPrice;
    
    // Getters and Setters
    public int getCartId() { return cartId; }
    public void setCartId(int cartId) { this.cartId = cartId; }
    
    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }
    
    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }
    
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    
    public String getAddedDate() { return addedDate; }
    public void setAddedDate(String addedDate) { this.addedDate = addedDate; }
    
    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }
    
    public double getProductPrice() { return productPrice; }
    public void setProductPrice(double productPrice) { this.productPrice = productPrice; }
    
    public double getTotalPrice() {
        return quantity * productPrice;
    }
    
    @Override
    public String toString() {
        return String.format("%-30s ₹%-10.2f x %-5d = ₹%-10.2f", 
            productName, productPrice, quantity, getTotalPrice());
    }
}