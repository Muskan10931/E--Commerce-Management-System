package com.ecommerce.ecommercesystem.service;

import com.ecommerce.ecommercesystem.model.Product;
import java.util.List;

/**
 * ProductService interface defines business logic for Product operations
 */
public interface ProductService {
    // Get all products
    List<Product> getAllProducts();
    
    // Get product by ID
    Product getProductById(int productId);
    
    // Add new product
    boolean addProduct(Product product);
    
    // Add product to cart
    boolean addToCart(int customerId, int productId, int quantity);
    
    // Get cart items
    List<Object[]> getCartItems(int customerId);
    
    // Remove from cart
    boolean removeFromCart(int cartId);
    
    // Clear cart
    boolean clearCart(int customerId);
}