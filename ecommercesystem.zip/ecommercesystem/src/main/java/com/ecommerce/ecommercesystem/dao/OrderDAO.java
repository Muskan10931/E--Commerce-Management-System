package com.ecommerce.ecommercesystem.dao;

import com.ecommerce.ecommercesystem.model.Order;
import java.util.List;

/**
 * OrderDAO interface defines database operations for Order entity
 */
public interface OrderDAO {
    // Create a new order
    int createOrder(Order order);
    
    // Add item to order
    boolean addOrderItem(int orderId, int productId, int quantity, double price);
    
    // Get orders by customer
    List<Order> getOrdersByCustomer(int customerId);
    
    // Get all orders
    List<Order> getAllOrders();
    
    // Update order status
    boolean updateOrderStatus(int orderId, String status);
}