package com.ecommerce.ecommercesystem.controller;

import java.util.Scanner;

/**
 * AdminController handles admin-specific operations
 */
public class AdminController {
    
    private Scanner scanner;
    
    public AdminController() {
        this.scanner = new Scanner(System.in);
    }
    
    /**
     * Admin login
     */
    public boolean login() {
        System.out.println("\n--- ADMIN LOGIN ---");
        
        System.out.print("Username: ");
        String username = scanner.nextLine();
        
        System.out.print("Password: ");
        String password = scanner.nextLine();
        
        // Simple admin validation (in real system, use database)
        if (username.equals("admin") && password.equals("admin123")) {
            System.out.println("✅ Admin login successful!");
            return true;
        } else {
            System.out.println("❌ Invalid admin credentials!");
            return false;
        }
    }
    
    /**
     * Show admin menu
     */
    public void showAdminMenu() {
        System.out.println("\n=== ADMIN DASHBOARD ===");
        System.out.println("Welcome, Administrator!");
    }
}