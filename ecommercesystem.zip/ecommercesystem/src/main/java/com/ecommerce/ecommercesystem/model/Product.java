package com.ecommerce.ecommercesystem.model;

/**
 * Product model class representing the products table
 * Contains product information like name, price, stock, etc.
 */
public class Product {
    private int productId;
    private String name;
    private String description;
    private double price;
    private int stock;
    private int categoryId;
    private String createdAt;
    
    // For display purposes
    private String categoryName;
    
    // Constructors
    public Product() {}
    
    public Product(String name, String description, double price, int stock, int categoryId) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.stock = stock;
        this.categoryId = categoryId;
    }
    
    // Getters and Setters
    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
    
    public int getCategoryId() { return categoryId; }
    public void setCategoryId(int categoryId) { this.categoryId = categoryId; }
    
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
    
    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }
    
    @Override
    public String toString() {
        return String.format("%-5d %-30s ₹%-10.2f %-10d", 
            productId, 
            name.length() > 30 ? name.substring(0, 27) + "..." : name,
            price, 
            stock);
    }
}