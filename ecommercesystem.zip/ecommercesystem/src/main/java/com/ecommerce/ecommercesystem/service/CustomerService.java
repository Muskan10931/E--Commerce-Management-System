package com.ecommerce.ecommercesystem.service;

import com.ecommerce.ecommercesystem.model.Customer;

/**
 * CustomerService interface defines business logic for Customer operations
 */
public interface CustomerService {
    // Register a new customer
    Customer registerCustomer(Customer customer);
    
    // Login customer
    Customer loginCustomer(String email, String password);
    
    // Get customer by ID
    Customer getCustomerById(int customerId);
}