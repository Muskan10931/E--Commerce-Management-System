package com.ecommerce.ecommercesystem.service;

import com.ecommerce.ecommercesystem.dao.ProductDAO;
import com.ecommerce.ecommercesystem.dao.ProductDAOImpl;
import com.ecommerce.ecommercesystem.model.Product;
import com.ecommerce.ecommercesystem.util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * ProductServiceImpl implements ProductService interface
 */
public class ProductServiceImpl implements ProductService {
    
    private ProductDAO productDAO;
    
    public ProductServiceImpl() {
        this.productDAO = new ProductDAOImpl();
    }
    
    @Override
    public List<Product> getAllProducts() {
        return productDAO.getAllProducts();
    }
    
    @Override
    public Product getProductById(int productId) {
        return productDAO.getProductById(productId);
    }
    
    @Override
    public boolean addProduct(Product product) {
        // Validate product
        if (product.getName() == null || product.getName().trim().isEmpty()) {
            System.out.println("Product name is required!");
            return false;
        }
        
        if (product.getPrice() <= 0) {
            System.out.println("Price must be greater than 0!");
            return false;
        }
        
        if (product.getStock() < 0) {
            System.out.println("Stock cannot be negative!");
            return false;
        }
        
        return productDAO.addProduct(product);
    }
    
    @Override
    public boolean addToCart(int customerId, int productId, int quantity) {
        // Check if product exists and has enough stock
        Product product = productDAO.getProductById(productId);
        if (product == null) {
            System.out.println("Product not found!");
            return false;
        }
        
        if (product.getStock() < quantity) {
            System.out.println("Not enough stock! Available: " + product.getStock());
            return false;
        }
        
        // Check if item already in cart
        String checkSql = "SELECT * FROM cart WHERE customer_id = ? AND product_id = ?";
        String updateSql = "UPDATE cart SET quantity = quantity + ? WHERE customer_id = ? AND product_id = ?";
        String insertSql = "INSERT INTO cart (customer_id, product_id, quantity) VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            // Check if item already exists in cart
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setInt(1, customerId);
                checkStmt.setInt(2, productId);
                ResultSet rs = checkStmt.executeQuery();
                
                if (rs.next()) {
                    // Update quantity
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                        updateStmt.setInt(1, quantity);
                        updateStmt.setInt(2, customerId);
                        updateStmt.setInt(3, productId);
                        return updateStmt.executeUpdate() > 0;
                    }
                } else {
                    // Insert new item
                    try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                        insertStmt.setInt(1, customerId);
                        insertStmt.setInt(2, productId);
                        insertStmt.setInt(3, quantity);
                        return insertStmt.executeUpdate() > 0;
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error adding to cart: " + e.getMessage());
        }
        return false;
    }
    
    @Override
    public List<Object[]> getCartItems(int customerId) {
        List<Object[]> cartItems = new ArrayList<>();
        String sql = "SELECT c.cart_id, p.product_id, p.name, p.price, c.quantity, " +
                    "(p.price * c.quantity) as total FROM cart c " +
                    "JOIN products p ON c.product_id = p.product_id " +
                    "WHERE c.customer_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Object[] item = new Object[6];
                item[0] = rs.getInt("cart_id");
                item[1] = rs.getInt("product_id");
                item[2] = rs.getString("name");
                item[3] = rs.getDouble("price");
                item[4] = rs.getInt("quantity");
                item[5] = rs.getDouble("total");
                cartItems.add(item);
            }
        } catch (SQLException e) {
            System.out.println("Error getting cart items: " + e.getMessage());
        }
        return cartItems;
    }
    
    @Override
    public boolean removeFromCart(int cartId) {
        String sql = "DELETE FROM cart WHERE cart_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, cartId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error removing from cart: " + e.getMessage());
        }
        return false;
    }
    
    @Override
    public boolean clearCart(int customerId) {
        String sql = "DELETE FROM cart WHERE customer_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, customerId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error clearing cart: " + e.getMessage());
        }
        return false;
    }
}