package com.ecommerce.ecommercesystem.dao;

import com.ecommerce.ecommercesystem.model.Customer;
import java.util.List;

/**
 * CustomerDAO interface defines all database operations for Customer entity
 */
public interface CustomerDAO {
    // Add a new customer
    boolean addCustomer(Customer customer);
    
    // Get customer by email and password (login)
    Customer getCustomerByEmailAndPassword(String email, String password);
    
    // Get customer by ID
    Customer getCustomerById(int customerId);
    
    // Get all customers
    List<Customer> getAllCustomers();
    
    // Check if email already exists
    boolean emailExists(String email);
}