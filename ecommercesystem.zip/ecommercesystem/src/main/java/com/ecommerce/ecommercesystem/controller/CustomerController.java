package com.ecommerce.ecommercesystem.controller;

import com.ecommerce.ecommercesystem.model.Customer;
import com.ecommerce.ecommercesystem.service.CustomerService;
import com.ecommerce.ecommercesystem.service.CustomerServiceImpl;
import java.util.Scanner;

/**
 * CustomerController handles user interactions for customer operations
 */
public class CustomerController {
    
    private CustomerService customerService;
    private Scanner scanner;
    
    public CustomerController() {
        this.customerService = new CustomerServiceImpl();
        this.scanner = new Scanner(System.in);
    }
    
    /**
     * Handle customer registration
     */
    public Customer register() {
        System.out.println("\n--- CUSTOMER REGISTRATION ---");
        
        System.out.print("Full Name: ");
        String name = scanner.nextLine();
        
        System.out.print("Email: ");
        String email = scanner.nextLine();
        
        System.out.print("Password: ");
        String password = scanner.nextLine();
        
        System.out.print("Phone: ");
        String phone = scanner.nextLine();
        
        System.out.print("Address: ");
        String address = scanner.nextLine();
        
        Customer customer = new Customer(name, email, password, phone, address);
        return customerService.registerCustomer(customer);
    }
    
    /**
     * Handle customer login
     */
    public Customer login() {
        System.out.println("\n--- CUSTOMER LOGIN ---");
        
        System.out.print("Email: ");
        String email = scanner.nextLine();
        
        System.out.print("Password: ");
        String password = scanner.nextLine();
        
        return customerService.loginCustomer(email, password);
    }
    
    /**
     * Show customer menu
     */
    public void showCustomerMenu(int customerId) {
        System.out.println("\n--- CUSTOMER DASHBOARD ---");
        
        Customer customer = customerService.getCustomerById(customerId);
        if (customer != null) {
            System.out.println("Welcome, " + customer.getName() + "!");
            System.out.println("Email: " + customer.getEmail());
            System.out.println("Phone: " + customer.getPhone());
            System.out.println("Address: " + customer.getAddress());
        }
    }
}