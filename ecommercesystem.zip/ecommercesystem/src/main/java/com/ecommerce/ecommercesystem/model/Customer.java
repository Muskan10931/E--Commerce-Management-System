package com.ecommerce.ecommercesystem.model;

/**
 * Customer model class representing the customers table
 * Contains customer information like name, email, address, etc.
 */
public class Customer {
    private int customerId;
    private String name;
    private String email;
    private String password;
    private String phone;
    private String address;
    private String createdAt;
    
    // Constructors
    public Customer() {}
    
    public Customer(String name, String email, String password, String phone, String address) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.phone = phone;
        this.address = address;
    }
    
    // Getters and Setters
    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
    
    @Override
    public String toString() {
        return String.format("Customer ID: %d\nName: %s\nEmail: %s\nPhone: %s", 
            customerId, name, email, phone);
    }
}